import 'package:flutter/material.dart';

class MoneyManagementPage extends StatefulWidget {
  const MoneyManagementPage({Key? key}) : super(key: key);

  @override
  _MoneyManagementPageState createState() => _MoneyManagementPageState();
}

class _MoneyManagementPageState extends State<MoneyManagementPage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _salaryController = TextEditingController();
  final TextEditingController _minValueController = TextEditingController();
  final TextEditingController _amountToPayController = TextEditingController();

  double _tracker = 0.0;

  @override
  void dispose() {
    _salaryController.dispose();
    _minValueController.dispose();
    _amountToPayController.dispose();
    super.dispose();
  }

  void _handleSubmit() {
    if (_formKey.currentState!.validate()) {
      double salary = double.parse(_salaryController.text);
      double minValue = double.parse(_minValueController.text);
      double amountToPay = double.parse(_amountToPayController.text);

      setState(() {
        _tracker = salary - amountToPay;
      });

      if (_tracker < minValue) {
        _showDialog('Warning', 'Your balance is below the minimum value.\nCurrent Balance: \$$_tracker');
      } else {
        _showDialog('Success', 'Payment successful.\nCurrent Balance: \$$_tracker');
      }
    }
  }

  void _showDialog(String title, String message) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(title),
          content: Text(message),
          actions: <Widget>[
            TextButton(
              child: Text('OK'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage("lib/images/newbg.jpg"),
                fit: BoxFit.cover,
              ),
            ),
          ),
          SingleChildScrollView(
            padding: const EdgeInsets.all(16.0),
            child: Card(
              elevation: 8.0,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
              ),
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Text(
                        'Enter Details',
                        style: TextStyle(
                          fontSize: 30,
                          fontWeight: FontWeight.bold,
                          color: Colors.blueAccent,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      SizedBox(height: 30),
                      _buildTextField(
                        controller: _salaryController,
                        labelText: 'Salary',
                        icon: Icons.attach_money,
                        keyboardType: TextInputType.number,
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please enter your salary';
                          }
                          return null;
                        },
                      ),
                      _buildTextField(
                        controller: _minValueController,
                        labelText: 'Minimum Value',
                        icon: Icons.warning,
                        keyboardType: TextInputType.number,
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please enter the minimum value';
                          }
                          return null;
                        },
                      ),
                      _buildTextField(
                        controller: _amountToPayController,
                        labelText: 'Amount to Pay',
                        icon: Icons.payment,
                        keyboardType: TextInputType.number,
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please enter the amount to pay';
                          }
                          return null;
                        },
                      ),
                      SizedBox(height: 30),
                      ElevatedButton(
                        onPressed: _handleSubmit,
                        style: ElevatedButton.styleFrom(
                          padding: EdgeInsets.symmetric(vertical: 20),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20),
                          ),
                        ),
                        child: Text(
                          'Submit',
                          style: TextStyle(fontSize: 22),
                        ),
                      ),
                      SizedBox(height: 30),
                      if (_tracker != 0.0)
                        Text(
                          'Current Balance: \$$_tracker',
                          style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            color: _tracker < 0 ? Colors.red : Colors.green,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      SizedBox(height: 30),
                      ElevatedButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        style: ElevatedButton.styleFrom(
                          padding: EdgeInsets.symmetric(vertical: 20),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20),
                          ),
                        ),
                        child: Text(
                          'Back',
                          style: TextStyle(fontSize: 22),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String labelText,
    required IconData icon,
    bool obscureText = false,
    TextInputType keyboardType = TextInputType.text,
    required String? Function(String?) validator,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 15),
      child: TextFormField(
        controller: controller,
        decoration: InputDecoration(
          labelText: labelText,
          labelStyle: TextStyle(fontSize: 20),
          prefixIcon: Icon(icon, size: 30),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(20),
          ),
        ),
        obscureText: obscureText,
        keyboardType: keyboardType,
        validator: validator,
      ),
    );
  }
}

void main() {
  runApp(MaterialApp(
    home: MoneyManagementPage(),
  ));
}
