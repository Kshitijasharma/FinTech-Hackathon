import 'package:flutter/material.dart';
import 'package:modernlogintute/pages/login_page.dart';
import 'package:modernlogintute/pages/home_page.dart';

class AuthPage extends StatelessWidget {
  const AuthPage({Key? key});

  // Simulating user authentication status
  bool checkAuthStatus() {
    // You can replace this with your actual authentication logic
    // For demonstration purposes, always returning true (user signed in)
    return true;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: FutureBuilder<bool>(
        future: Future.delayed(Duration(seconds: 2), () => checkAuthStatus()),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            // Show a loading indicator while checking authentication status
            return Center(
              child: CircularProgressIndicator(),
            );
          } else {
            if (snapshot.hasError) {
              // Handle error
              return Center(
                child: Text('Error: ${snapshot.error}'),
              );
            } else {
              // If user is signed in, show home page
              // Otherwise, show login page
              if (snapshot.data == true) {
                return HomePage(); // User is signed in
              } else {
                return LoginPage(); // User is not signed in
              }
            }
          }
        },
      ),
    );
  }
}
