import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:csv/csv.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Fraud Detection',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: FraudDetectionPage(),
    );
  }
}

class FraudDetectionPage extends StatefulWidget {
  const FraudDetectionPage({Key? key}) : super(key: key);

  @override
  _FraudDetectionPageState createState() => _FraudDetectionPageState();
}

class _FraudDetectionPageState extends State<FraudDetectionPage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _merchantIdController = TextEditingController();

  List<Transaction> _recentTransactions = [];

  @override
  void initState() {
    super.initState();
    _loadDataset();
  }

  @override
  void dispose() {
    _merchantIdController.dispose();
    super.dispose();
  }

  void _loadDataset() async {
    final rawData = await rootBundle.loadString('assets/transactions.csv');
    List<List<dynamic>> listData = const CsvToListConverter().convert(rawData);

    setState(() {
      _recentTransactions = listData.skip(1).map((row) {
        return Transaction(
          transactionId: row[0].toString().trim(),
          customerId: row[1].toString(),
          merchantId: row[2].toString(),
          amount: double.parse(row[3].toString()),
          transactionTime: DateTime.parse(row[4].toString()),
          cardType: row[5].toString(),
          location: row[6].toString(),
          purchaseCategory: row[7].toString(),
          customerAge: int.parse(row[8].toString()),
          isFraudulent: row[9] == 1,
        );
      }).toList();
    });
  }

  void _handleSubmit() {
    if (_formKey.currentState!.validate()) {
      final merchantId = _merchantIdController.text.trim();

      // Check if the merchantId is flagged as fraudulent
      bool isFraudulent = _isFraudulent(merchantId, _recentTransactions);

      if (isFraudulent) {
        _showDialog('Fraudulent activity detected for Merchant ID!');
      } else {
        _showDialog('Merchant ID is safe.');
      }
    }
  }

  bool _isFraudulent(String merchantId, List<Transaction> recentTransactions) {
    //for (var transaction in recentTransactions) {

    if(recentTransactions.any((transaction) => transaction.merchantId == merchantId))
        {
          return true;

    }
   print(merchantId);
   // print(transaction.merchantId);

    //}
    // If no matching merchantId is found, return false indicating it is safe
    return false;
   }


  void _showDialog(String message) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Transaction Status'),
          content: Text(message),
          actions: <Widget>[
            TextButton(
              child: Text('OK'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Fraud Detection'),
      ),
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage("lib/images/newbg.jpg"),
                fit: BoxFit.cover,
              ),
            ),
          ),
          SingleChildScrollView(
            padding: const EdgeInsets.all(16.0),
            child: Container(
              padding: const EdgeInsets.all(16.0),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.8), // Semi-transparent background
                borderRadius: BorderRadius.circular(20),
              ),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(
                      'Enter Merchant ID',
                      style: TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.bold,
                        color: Colors.blueAccent,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    SizedBox(height: 30),
                    _buildTextField(
                      controller: _merchantIdController,
                      labelText: 'Merchant ID',
                      icon: Icons.store,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter the Merchant ID';
                        }
                        return null;
                      },
                    ),
                    SizedBox(height: 30),
                    ElevatedButton(
                      onPressed: _handleSubmit,
                      style: ElevatedButton.styleFrom(
                        padding: EdgeInsets.symmetric(vertical: 20),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                      ),
                      child: Text(
                        'Submit',
                        style: TextStyle(fontSize: 20),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String labelText,
    required IconData icon,
    bool obscureText = false,
    TextInputType keyboardType = TextInputType.text,
    required String? Function(String?) validator,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: TextFormField(
        controller: controller,
        decoration: InputDecoration(
          labelText: labelText,
          prefixIcon: Icon(icon),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(20),
          ),
        ),
        obscureText: obscureText,
        keyboardType: keyboardType,
        validator: validator,
      ),
    );
  }
}

class Transaction {
  String transactionId;
  String customerId;
  String merchantId;
  double amount;
  DateTime transactionTime;
  String cardType;
  String location;
  String purchaseCategory;
  int customerAge;
  bool isFraudulent;

  Transaction({
  required this.transactionId,
  required this.customerId,
  required this.merchantId,
  required this.amount,
  required this.transactionTime,
  required this.cardType,
  required this.location,
  required this.purchaseCategory,
  required this.customerAge,
  required this.isFraudulent,
});
}
