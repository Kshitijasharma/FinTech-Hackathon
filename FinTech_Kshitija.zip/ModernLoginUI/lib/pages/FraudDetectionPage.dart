import 'package:csv/csv.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Fraud Detection',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: FraudDetectionPage(),
    );
  }
}

class FraudDetectionPage extends StatefulWidget {
  const FraudDetectionPage({Key? key}) : super(key: key);

  @override
  _FraudDetectionPageState createState() => _FraudDetectionPageState();
}

class _FraudDetectionPageState extends State<FraudDetectionPage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _merchantIdController = TextEditingController();
  final TextEditingController _customerIdController = TextEditingController();
  final TextEditingController _amountController = TextEditingController();
  final TextEditingController _transactionTimeController = TextEditingController();
  final TextEditingController _cardTypeController = TextEditingController();
  final TextEditingController _locationController = TextEditingController();
  final TextEditingController _purchaseCategoryController = TextEditingController();
  final TextEditingController _customerAgeController = TextEditingController();

  List<Transaction> _recentTransactions = [];
  List<Transaction> _currentTransactions = [];
  String _merchantId = '';
  bool _isFraudulent = false;

  @override
  void initState() {
    super.initState();
    _loadDataset();

  }

  @override
  void dispose() {
    _merchantIdController.dispose();
    _customerIdController.dispose();
    _amountController.dispose();
    _transactionTimeController.dispose();
    _cardTypeController.dispose();
    _locationController.dispose();
    _purchaseCategoryController.dispose();
    _customerAgeController.dispose();
    super.dispose();
  }

  void _loadDataset() async {
   // Uncomment if using CSV parsing
    final rawData = await rootBundle.loadString('assets/transactions.csv');
    List<List<dynamic>> listData = const CsvToListConverter().convert(rawData);

    List<List<dynamic>> listData2 = [
      [
        'transactionId',
        'customerId',
        'merchantId',
        'amount',
        'transactionTime',
        'cardType',
        'location',
        'purchaseCategory',
        'customerAge',
        'isFraudulent'
      ],
      [
        '1',
        'cust1',
        'merch1',
        100.0,
        '2023-01-01T10:00:00',
        'Visa',
        'New York',
        'Electronics',
        30,
        0
      ],
      [
        '2',
        'cust2',
        'merch2',
        200.0,
        '2023-01-02T11:00:00',
        'MasterCard',
        'San Francisco',
        'Clothing',
        25,
        1
      ],
      [
        '3',
        'cust3',
        'merch1',
        150.0,
        '2023-01-03T12:00:00',
        'Amex',
        'Los Angeles',
        'Groceries',
        40,
        0
      ],
    ];

    setState(() {
      _recentTransactions = listData.skip(1).map((row) {
        return Transaction(
          transactionId: row[0].toString().trim(),
          customerId: row[1].toString(),
          merchantId: row[2].toString(),
          amount: double.parse(row[3].toString()),
          transactionTime: DateTime.parse(row[4].toString()),
          cardType: row[6].toString(),
          location: row[7].toString(),
          purchaseCategory: row[8].toString(),
          customerAge: int.parse(row[9].toString()),
          isFraudulent: row[5] == 1,
        );
      }).toList();
    });
  }

  void _handleSubmit() {
    if (_formKey.currentState!.validate()) {
      final transaction = Transaction(
        transactionId: DateTime.now().toIso8601String(), // Or generate as needed
        customerId: _customerIdController.text.trim(),
        merchantId: _merchantIdController.text.trim(),
        amount: double.tryParse(_amountController.text.trim()) ?? 0.0,
        //transactionTime: DateTime.parse(_transactionTimeController.text.trim()),
        transactionTime: DateTime.now(),

        cardType: _cardTypeController.text.trim(),
        location: _locationController.text.trim(),
        purchaseCategory: _purchaseCategoryController.text.trim(),
        customerAge: int.tryParse(_customerAgeController.text.trim()) ?? 0,
        isFraudulent: false, // Or set based on your logic
      );

      setState(() {
        _currentTransactions.add(transaction);
        _isFraudulent = _checkFraudulence(transaction);
        _merchantId = transaction.merchantId;
      });

      final message = _isFraudulent
          ? 'Fraudulent activity detected for Merchant ID $_merchantId!'
          : 'Merchant ID $_merchantId is safe.';
      _showDialog(message);
    }
  }

  bool _checkFraudulence(Transaction transaction) {
    // return _recentTransactions.any((t) => t.merchantId == transaction.merchantId && t.isFraudulent);
    if (_recentTransactions.any((t) => t.merchantId == transaction.merchantId && t.isFraudulent==true )) {
      return true;
    }
    return false;

  }

  void _showDialog(String message) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Transaction Status'),
          content: Text(message),
          actions: <Widget>[
            TextButton(
              child: Text('OK'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Fraud Detection'),
      ),
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage("lib/images/newbg.jpg"),
                fit: BoxFit.cover,
              ),
            ),
          ),
          SingleChildScrollView(
            padding: const EdgeInsets.all(16.0),
            child: Container(
              padding: const EdgeInsets.all(16.0),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.8), // Semi-transparent background
                borderRadius: BorderRadius.circular(20),
              ),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(
                      'Enter Transaction Details',
                      style: TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.bold,
                        color: Colors.blueAccent,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    SizedBox(height: 30),
                    _buildTextField(
                      controller: _merchantIdController,
                      labelText: 'Merchant ID',
                      icon: Icons.store,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter the Merchant ID';
                        }
                        return null;
                      },
                    ),
                    _buildTextField(
                      controller: _customerIdController,
                      labelText: 'Customer ID',
                      icon: Icons.person,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter the Customer ID';
                        }
                        return null;
                      },
                    ),
                    _buildTextField(
                      controller: _amountController,
                      labelText: 'Amount',
                      icon: Icons.attach_money,
                      keyboardType: TextInputType.number,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter the amount';
                        }
                        return null;
                      },
                    ),
                    /* _buildTextField(
                      controller: _transactionTimeController,
                      labelText: 'Transaction Time (ISO8601)',
                      icon: Icons.timer,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter the transaction time';
                        }
                        try {
                          DateTime.parse(value);
                        } catch (e) {
                          return 'Invalid date format';
                        }
                        return null;
                      },
                    ),*/
                    _buildTextField(
                      controller: _cardTypeController,
                      labelText: 'Card Type',
                      icon: Icons.credit_card,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter the card type';
                        }
                        return null;
                      },
                    ),
                    _buildTextField(
                      controller: _locationController,
                      labelText: 'Location',
                      icon: Icons.location_on,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter the location';
                        }
                        return null;
                      },
                    ),
                    _buildTextField(
                      controller: _purchaseCategoryController,
                      labelText: 'Purchase Category',
                      icon: Icons.category,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter the purchase category';
                        }
                        return null;
                      },
                    ),
                    _buildTextField(
                      controller: _customerAgeController,
                      labelText: 'Customer Age',
                      icon: Icons.calendar_today,
                      keyboardType: TextInputType.number,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter the customer age';
                        }
                        return null;
                      },
                    ),
                    SizedBox(height: 30),
                    ElevatedButton(
                      onPressed: _handleSubmit,
                      style: ElevatedButton.styleFrom(
                        padding: EdgeInsets.symmetric(vertical: 20),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                      ),
                      child: Text(
                        'Submit',
                        style: TextStyle(fontSize: 20),
                      ),
                    ),
                    SizedBox(height: 30),
                    // Display Merchant ID and Fraud Status
                    /*Text(
                      'Merchant ID: $_merchantId',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),*/
                    Text(
                      'Fraud Status: ${_isFraudulent ? "Fraudulent" : "Safe"}',
                      style: TextStyle(
                        fontSize: 18,
                        color: _isFraudulent ? Colors.red : Colors.green,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String labelText,
    required IconData icon,
    bool obscureText = false,
    TextInputType keyboardType = TextInputType.text,
    required String? Function(String?) validator,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: TextFormField(
        controller: controller,
        decoration: InputDecoration(
          labelText: labelText,
          prefixIcon: Icon(icon),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(20),
          ),
        ),
        obscureText: obscureText,
        keyboardType: keyboardType,
        validator: validator,
      ),
    );
  }
}

class Transaction {
  final String transactionId;
  final String customerId;
  final String merchantId;
  final double amount;
  final DateTime transactionTime;
  final String cardType;
  final String location;
  final String purchaseCategory;
  final int customerAge;
  final bool isFraudulent;

  Transaction({
    required this.transactionId,
    required this.customerId,
    required this.merchantId,
    required this.amount,
    required this.transactionTime,
    required this.cardType,
    required this.location,
    required this.purchaseCategory,
    required this.customerAge,
    required this.isFraudulent,
  });
}
