// models/transaction.dart
class Transaction {
  final String transactionId;
  final String customerId;
  final String merchantId;
  final double amount;
  final DateTime transactionTime;
  final String cardType;
  final String location;
  final String purchaseCategory;
  final int customerAge;
  bool isFraudulent;

  Transaction({
    required this.transactionId,
    required this.customerId,
    required this.merchantId,
    required this.amount,
    required this.transactionTime,
    required this.cardType,
    required this.location,
    required this.purchaseCategory,
    required this.customerAge,
    this.isFraudulent = false,
  });
}
