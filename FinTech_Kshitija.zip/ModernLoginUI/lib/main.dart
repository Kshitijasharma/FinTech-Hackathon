import 'package:flutter/material.dart';
import 'package:modernlogintute/pages/auth_page.dart';
import 'package:modernlogintute/pages/login_page.dart';
import 'package:modernlogintute/pages/home_page.dart';
import 'package:modernlogintute/pages/speech_to_text.dart';

void main() async {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      initialRoute: '/login', // Specify initial route
      routes: {
        '/login': (context) => LoginPage(), // Define LoginPage route
        '/auth': (context) => AuthPage(), // Define AuthPage route
        '/home': (context) => HomePage(), // Define HomePage route
        '/speech' :(context) => SpeechToText(),
      },
    );
  }
}
