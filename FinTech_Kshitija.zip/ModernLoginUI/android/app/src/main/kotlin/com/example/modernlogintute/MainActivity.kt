package com.example.modernlogintute

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
